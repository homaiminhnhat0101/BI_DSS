# businessintelligencepj
The system typically includes a data warehouse or data mart where data is stored in a structured and organized manner, as well as tools for data modeling, extraction, transformation,loading (ETL) and dashboard systems. In this assignment, we will build a BIDSS project with Azure Cloud platform and Tableau for dashboard system.
